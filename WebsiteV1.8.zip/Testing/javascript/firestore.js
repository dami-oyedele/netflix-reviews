var firebaseConfig = {
  apiKey: "AIzaSyDTtTuK9BE3Z-veW0iXTFXuWyQ29PYy-aU",
  authDomain: "netrev-58ec6.firebaseapp.com",
  projectId: "netrev-58ec6",
  storageBucket: "netrev-58ec6.appspot.com",
  messagingSenderId: "581497609675",
  appId: "1:581497609675:web:d7e3b98dfc16b10427aa4e"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
//-----------------READY DATA---------------------

var titleV, genreV, usernameV, ratingV, reviewV;
function Ready(){
  titleV = document.getElementById("titlebox").value;
  genreV = document.getElementById("genrebox").value;
  usernameV = document.getElementById("usernamebox").value;
  ratingV = document.getElementById("ratingbox").value;
  reviewV = document.getElementById("reviewbox").value;
}

//---------------INSERT PROCESS---------------------
document.getElementById('insert').onclick = function(){
  Ready();
  firebase.database().ref('review/'+titleV).set({
    NameOM: titleV,
    GenreOM: genreV,
    Username: usernameV,
    RatingOM: ratingV,
    ReviewOM: reviewV

  });
}